<?php
/**
 * @category   MW
 * @package    MW_ProductQuickView
 * @version    1.0.0
 * @copyright  Copyright (c) 2012 Mage Whiz. (http://www.magewhiz.com)
 */

class MW_ProductQuickView_Block_Category_Quickview extends Mage_Catalog_Block_Product_Abstract
{
    protected $_mwCache = array();

    public function setProduct($product)
    {
        $_product = clone $product;
        $_product->getResource()->load($_product);

        if ($_product->getHasOptions()) {
            foreach ($_product->getProductOptionsCollection() as $option) {
                $option->setProduct($_product);
                $_product->addOption($option);
            }
        }

        $this->setData('product', $_product);

        return $this;
    }

    public function getOptionValues()
    {
        $options = array();
        $_product = $this->getProduct();
        $separator = $this->helper('productquickview')->getConfig('attribute/option_separator', false);
        if($this->helper('productquickview')->getConfig('attribute/show_customoption'))
        {
            foreach($_product->getOptions() as $_option){
                $_values = array();
                foreach ($_option->getValues() as $_value) {
                    $_values[] = $_value->getTitle();
                }

                $options[] = array(
                    'label' => $_option->getTitle(),
                    'value' => implode($separator, $_values)
                );
            }
        }

        if($this->helper('productquickview')->getConfig('attribute/show_configurableoption'))
        {
            if($_product->isConfigurable())
            {
                $_attributes = $_product->getTypeInstance()->getConfigurableAttributes($_product);
                {
                    foreach($_attributes as $_attribute)
                    {
                        $_values = array();
                        foreach($_attribute->getPrices() as $_value)
                        {
                            $_values[] = $_value['label'];
                        }

                        $options[] = array(
                            'label' => $_attribute->getLabel(),
                            'value' => implode($separator, $_values)
                        );
                    }
                }
            }
        }

        return $options;
    }

    public function getAdditionData()
    {
        $data = array();
        $_product = $this->getProduct();
        foreach($_product->getAttributes() as $attribute)
        {
            if($attribute->getIsVisibleOnFront() && $_product->hasData($attribute->getAttributeCode()) && $this->isShowAttribute($attribute->getAttributeCode()))
            {
                $data[] = array(
                    'label' => $attribute->getFrontendLabel(),
                    'value' => $attribute->getFrontend()->getValue($_product),
                    'code'  => $attribute->getAttributeCode()
                );
            }
        }

        return $data;
    }

    public function isShowAttribute($attributeCode)
    {
        if(!isset($this->_mwCache['show_attribute'][$attributeCode])){
            if(!isset($this->_mwCache['config_attributes']))
                $this->_mwCache['config_attributes'] = $this->helper('productquickview')->getConfigSelect('attribute/attributes');
            if(!isset($this->_mwCache['config_is_show_attribute']))
                $this->_mwCache['config_is_show_attribute'] = $this->helper('productquickview')->getConfig('attribute/attribute_type') == 'show';

            $this->_mwCache['show_attribute'][$attributeCode] = $this->_mwCache['config_is_show_attribute'] == in_array($attributeCode, $this->_mwCache['config_attributes']);
        }

        return $this->_mwCache['show_attribute'][$attributeCode];
    }

    public function isShowImage()
    {
        return $this->helper('productquickview')->getConfig('general/show_image');
    }
}