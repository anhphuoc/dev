# command syntax: ./install.sh $1 $2
# $1 -- absolute extension source path to the magento root of SVN repo -- example: /home/dev/magento
# $2 -- absolute site path to the magento root of the site -- example /var/www/sites/community/5
# ** DO NOT include slash at the end of paths
# EXAMPLE: ./install.sh /home/dev/magento /var/www/sites/community/5
#
#------unlink
unlink $2/app/etc/modules/MW_ProductQuickView.xml
unlink $2/app/code/local/MW/ProductQuickView
unlink $2/app/design/frontend/base/default/template/mw/productquickview
unlink $2/app/design/frontend/base/default/layout/mw_productquickview.xml
unlink $2/skin/frontend/base/default/css/mw/productquickview
unlink $2/skin/frontend/base/default/js/mw/productquickview
#
#
#
#
#
ln -s $1/Step\ 2/app/etc/modules/MW_ProductQuickView.xml $2/app/etc/modules/MW_ProductQuickView.xml
#
mkdir $2/app/code/local
mkdir $2/app/code/local/MW
ln -s $1/Step\ 1/app/code/local/MW/ProductQuickView $2/app/code/local/MW/ProductQuickView
#
mkdir $2/app/design/frontend/base/default/template/mw
ln -s $1/Step\ 1/app/design/frontend/base/default/template/mw/productquickview $2/app/design/frontend/base/default/template/mw/productquickview
ln -s $1/Step\ 1/app/design/frontend/base/default/layout/mw_productquickview.xml $2/app/design/frontend/base/default/layout/mw_productquickview.xml
#
#
mkdir $2/skin/frontend/base/default/css/mw
mkdir $2/skin/frontend/base/default/js/mw
ln -s $1/Step\ 1/skin/frontend/base/default/css/mw/productquickview $2/skin/frontend/base/default/css/mw/productquickview
ln -s $1/Step\ 1/skin/frontend/base/default/js/mw/productquickview $2/skin/frontend/base/default/js/mw/productquickview
