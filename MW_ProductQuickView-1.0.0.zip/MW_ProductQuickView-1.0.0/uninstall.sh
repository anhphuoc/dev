# command syntax: ./uninstall.sh $1
# $1 -- absolute site path to the magento root of the site -- example /var/www/sites/community/5
# ** DO NOT include slash at the end of paths
# EXAMPLE: ./uninstall.sh /var/www/sites/community/5
#
#------unlink
unlink $1/app/etc/modules/MW_ProductQuickView.xml
unlink $1/app/code/local/MW/ProductQuickView
unlink $1/app/design/frontend/base/default/template/mw/productquickview
unlink $1/app/design/frontend/base/default/layout/mw_productquickview.xml
unlink $1/skin/frontend/base/default/css/mw/productquickview
unlink $1/skin/frontend/base/default/js/mw/productquickview
#
unlink $1/app/code/local/MW/All
unlink $1/app/design/adminhtml/default/default/template/mw_all
unlink $1/app/design/adminhtml/default/default/layout/mw_all.xml
unlink $1/app/etc/modules/MW_All.xml
unlink $1/skin/adminhtml/default/default/mw/all
unlink $1/skin/adminhtml/default/default/mw/images