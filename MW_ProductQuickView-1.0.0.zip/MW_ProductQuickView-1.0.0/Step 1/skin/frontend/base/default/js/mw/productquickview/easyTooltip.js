/*
 * 	Easy Tooltip 1.0 - jQuery plugin
 *	written by Alen Grakalic	
 *	http://cssglobe.com/post/4380/easy-tooltip--jquery-plugin
 *
 *	Copyright (c) 2009 Alen Grakalic (http://cssglobe.com)
 *	Dual licensed under the MIT (MIT-LICENSE.txt)
 *	and GPL (GPL-LICENSE.txt) licenses.
 *
 *	Built for jQuery library
 *	http://jquery.com
 *
 */
 
(function($) {

	$.fn.easyTooltip = function(options){
	  
		// default configuration properties
		var defaults = {	
			xOffset: 10,		
			yOffset: 25,
			tooltipId: "easyTooltip",
			clickRemove: false,
			content: "",
			useElement: "",
            trigger: "mouseenter",
            onShow: function(){},
            mouseMoveX: true,
            mouseMoveY: true,
            focus: false,
            showTime: 500,
            hideTime: 500,
            isPopup: false
		};
			
		var options = $.extend(defaults, options);  
		var content;
        var hide_timeout;
        var show_timeout;
        var is_show = false;
        var current_element = false;

        var methods = {
            show: function(e){
                content = (options.content != "") ? options.content : title;
                content = (options.useElement != "") ? $("#" + options.useElement).html() : content;
                $(this).attr("title","");

                if (content != "" && content != undefined){
                    window.clearTimeout(hide_timeout);
                    $("#" + options.tooltipId).remove();

                    $("body").append("<div id='"+ options.tooltipId +"'>"+ content +"</div>");
                    $("#" + options.tooltipId)
                        .css("position","absolute")
                        .css("top",(e.pageY - options.yOffset) + "px")
                        .css("left",(e.pageX + options.xOffset) + "px");
                    options.onShow(e, this, $("#" + options.tooltipId));
                    $("#" + options.tooltipId)
                        .css("display","none")
                        .fadeIn("fast");

                    if(options.focus && !options.isPopup)
                    {
                        $("#" + options.tooltipId).mouseenter(function(){
                            window.clearTimeout(hide_timeout);
                        });
                        $("#" + options.tooltipId).mouseleave(function(){
                            hide_timeout = setTimeout(function(){$("#" + options.tooltipId).remove();}, options.hideTime);
                        });
                    }

                    if(options.isPopup)
                    {
                        $("#" + options.tooltipId)
                            .append('<a href="#" id="easytooltip-close-button">close</a>')
                            .addClass('easy-popup')
                            .css("position","fixed")
                        ;
                        $("body").append('<div id="easytooltip-mark"></div>');
                        $("#easytooltip-close-button").bind('click', function(){
                            $("#" + options.tooltipId).remove();
                            $("#easytooltip-mark").remove();
                            $(this).attr("title",title);
                            return false;
                        });
                    }
                }

                is_show = true;
            },

            close : function() {

            }
        };

		this.each(function() {  				
			var title = $(this).attr("title");				
			$(this).bind(options.trigger, function(e){
                window.clearTimeout(show_timeout);
                window.clearTimeout(hide_timeout);

                if($("#" + options.tooltipId).length && current_element && current_element == this)
                {
                    is_show = true;
                    return false;
                }

                var self = this;
                show_timeout = setTimeout(function(){show(self, e);}, options.showTime);

                e.preventDefault();
                return false;
			});

            function show(elem, e){
                content = (options.content != "") ? options.content : title;
                content = (options.useElement != "") ? $("#" + options.useElement).html() : content;
                $(elem).attr("title","");

                current_element = elem;

                if (content != "" && content != undefined){
                    $("#" + options.tooltipId).remove();

                    $("body").append("<div id='"+ options.tooltipId +"'>"+ content +"</div>");
                    $("#" + options.tooltipId)
                        .css("position","absolute")
                        .css("top",(e.pageY - options.yOffset) + "px")
                        .css("left",(e.pageX + options.xOffset) + "px");
                    options.onShow(e, elem, $("#" + options.tooltipId));
                    $("#" + options.tooltipId)
                        .css("display","none")
                        .fadeIn("fast");

                    if(options.focus && !options.isPopup)
                    {
                        $("#" + options.tooltipId).mouseenter(function(){
                            window.clearTimeout(hide_timeout);
                        });
                        $("#" + options.tooltipId).mouseleave(function(){
                            hide_timeout = setTimeout(function(){$("#" + options.tooltipId).remove();}, options.hideTime);
                        });
                    }

                    if(options.isPopup)
                    {
                        $("#" + options.tooltipId)
                            .append('<a href="#" id="easytooltip-close-button">close</a>')
                            .addClass('easy-popup')
                            .css("position","fixed")
                        ;
                        $("body").append('<div id="easytooltip-mark"></div>');
                        $("#easytooltip-close-button, #easytooltip-mark").bind('click', function(){
                            $("#" + options.tooltipId).remove();
                            $("#easytooltip-mark").remove();
                            $(elem).attr("title",title);
                            return false;
                        });
                    }
                }

                is_show = true;
            }

            function close(elem)
            {
                $("#" + options.tooltipId).remove();
                $(elem).attr("title",title);
                is_show = false;
            }

            if(!options.isPopup)
            {
                $(this).mouseleave(function(){
                    is_show = false;
                    if(options.focus){
                        //$("#" + options.tooltipId).delay(2000).hide();
                        hide_timeout = setTimeout(function(){$("#" + options.tooltipId).remove();}, options.hideTime);
                    }else{
                        $("#" + options.tooltipId).remove();
                    }
                    $(this).attr("title",title);
                });
                $(this).mousemove(function(e){
                    if(!is_show) return false;
                    if(options.mouseMoveX)
                        $("#" + options.tooltipId).css("left",(e.pageX + options.xOffset) + "px");
                    if(options.mouseMoveY)
                        $("#" + options.tooltipId).css("top",(e.pageY - options.yOffset) + "px");
                });
                if(options.clickRemove){
                    $(this).mousedown(function(e){
                        $("#" + options.tooltipId).remove();
                        $(this).attr("title",title);
                    });
                }
            }
		});
	  
	};

})(jQuery);
