<?php
/**
 * @category   MW
 * @package    MW_ProductQuickView
 * @version    1.0.0
 * @copyright  Copyright (c) 2012 Mage Whiz. (http://www.magewhiz.com)
 */

class MW_ProductQuickView_Helper_Data extends Mage_Core_Helper_Abstract
{
    protected $_configCache = array();

    public function getConfig($key, $trim = true)
    {
        if(!array_key_exists($key, $this->_configCache))
        {
            $this->_configCache[$key] = $trim ? trim(Mage::getStoreConfig("mw_productquickview/$key")) : Mage::getStoreConfig("mw_productquickview/$key");
        }
        return $this->_configCache[$key];
    }

    public function getConfigSelect($key)
    {
        $key_value = "{$key}_values";
        if(!array_key_exists($key_value, $this->_configCache))
        {
            $this->_configCache[$key_value] = preg_split('/,/i', $this->getConfig($key));
        }
        return $this->_configCache[$key_value];
    }
}