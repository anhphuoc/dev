<?php
/**
 * @category   MW
 * @package    MW_ProductQuickView
 * @version    1.0.0
 * @copyright  Copyright (c) 2012 Mage Whiz. (http://www.magewhiz.com)
 */
class MW_ProductQuickView_Model_System_Config_Source_Attributes
{
    public function toOptionArray()
    {
        /*$collection = Mage::getResourceModel('eav/entity_attribute_collection')
            ->setEntityTypeFilter( Mage::getModel('eav/entity')->setType('catalog_product')->getTypeId() )
            ->addVisibleFilter();*/
        $collection = Mage::getResourceModel('catalog/product_attribute_collection')
            ->addVisibleFilter()
            ->removePriceFilter();
        $cols = array();

        /*$attributeCodes = Mage::getSingleton('eav/config')
            ->getEntityAttributeCodes('catalog_product');*/

        foreach($collection->getItems() as $col) {
            $cols[] = array('value' => $col->getAttributeCode(),   'label' => $col->getFrontendLabel());
        }
        return $cols;
    }
}