<?php
/**
 * @category   MW
 * @package    MW_ProductQuickView
 * @version    1.0.0
 * @copyright  Copyright (c) 2012 Mage Whiz. (http://www.magewhiz.com)
 */
class MW_ProductQuickView_Model_System_Config_Source_Showby
{
    public function toOptionArray()
    {
        return array(
            array('value' => 'mousehover', 'label' => 'Mouse Hovered'),
            array('value' => 'mouseclick', 'label' => 'Button Clicked')
        );
    }
}