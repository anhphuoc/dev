<?php
/**
 * @category   MW
 * @package    MW_ProductQuickView
 * @version    1.0.0
 * @copyright  Copyright (c) 2012 Mage Whiz. (http://www.magewhiz.com)
 */

class MW_ProductQuickView_Block_Category_List extends Mage_Core_Block_Template
{
    protected $_productCollection;
    public function getProductCollection()
    {
        if (is_null($this->_productCollection)) {
            $layer = $this->getLayer();
            $category = $this->getCategoryInFilter();

            if ($category && $category->getId()) {
                $origCategory = $layer->getCurrentCategory();
                $layer->setCurrentCategory($category);
                $this->_productCollection = $layer->getProductCollection();
                $layer->setCurrentCategory($origCategory);
            }else
            {
                $this->_productCollection = $layer->getProductCollection();
            }
        }
        return $this->_productCollection;
    }

    public function getLayer()
    {
        $layer = Mage::registry('current_layer');
        if ($layer) {
            return $layer;
        }
        return Mage::getSingleton('catalog/layer');
    }

    protected function getCategoryInFilter()
    {
        if(Mage::registry('current_category_filter')) return Mage::registry('current_category_filter');
        return Mage::registry('current_category');
    }
}